// src/models/FileModel.ts

export interface File {
    id: string;
    userId: string;
    fileName: string;
    csvFileName: string;
}

