

export const USER = "USER";
export const ADMIN = "admin";
export const ACTIVE = "active";