"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class GenericReturn {
    constructor(id, statusCode, message, result, data) {
        this.id = id;
        this.statusCode = statusCode;
        this.message = message;
        this.result = result;
        this.data = data;
    }
}
exports.default = GenericReturn;
//# sourceMappingURL=genericReturn.js.map