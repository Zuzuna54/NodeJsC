"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ACTIVE = exports.ADMIN = exports.USER = void 0;
exports.USER = "USER";
exports.ADMIN = "admin";
exports.ACTIVE = "active";
//# sourceMappingURL=consts.js.map